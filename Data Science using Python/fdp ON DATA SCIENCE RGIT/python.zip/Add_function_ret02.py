def funAdd(num1,num2):
    res=num1+num2
    return res

n1=int(input(" enter a no: "))
n2=int(input(" enter a no: "))
print('A=',n1)
print('B=',n2)
print(n1,'+',n2,'=',funAdd(n1,n2))
#n3=funAdd(n1,n2)
#print(n1,'+',n2,'=',n3)
