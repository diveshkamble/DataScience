num1=int(input(" enter a no: "))# user input
num2=float(input(" enter a no: "))# int to accept integer float to float
res=num1+num2
# to print numbers
print(num1,'+',num2,'=',res)
# to print string
print(str(num1)+"+"+str(num2)+"="+str(res))
