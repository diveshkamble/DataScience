num1=int(input(" enter a no: "))# user input
if num1%2==0:
    print(num1,'Even')


else:
    print(num1,'odd')

print('we learnt if keyword')
