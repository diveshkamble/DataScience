import demo11
demo11.fblue()
print("hello")
