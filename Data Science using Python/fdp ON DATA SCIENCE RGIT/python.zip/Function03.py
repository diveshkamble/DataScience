def printinfo(name,age=25):
    print('Name: ',name)
    print('Age : ',age)
    return


printinfo(age=50, name='Trainee')
printinfo('vishal',19)
printinfo(19,'vishal')
printinfo('python')
