def funAdd(num1,num2):
    res=num1+num2
    print(num1,'+',num2,'=',res)
    print(num1,'+',num2,'=',res)
    return None

n1=int(input(" enter a no: "))
n2=int(input(" enter a no: "))
funAdd(n1,n2)
