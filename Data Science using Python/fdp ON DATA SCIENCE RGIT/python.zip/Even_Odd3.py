num1=int(input(" enter a no: "))# user input
if num1%2==0:
    print(num1,' is Even')
    print('if block executed')


else:
    print(num1,' is odd')
    print('else block executed')
