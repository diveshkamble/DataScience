#Numpy operation
#max ,min ,sum
import numpy as np
# 1D
a=np.array([1,2,3,4])
print(a)
print(" Max : ",a.max())
print(" Min : ",a.min())
print(" sum : ",a.sum())

#2 D
a=np.array([(1,2,3,4),(5,6,7,8)])
print(a)
print(" Max : ",a.max())
print(" Min : ",a.min())
print(" sum : ",a.sum())
