# what is numpy
# numpy vs list
#numpy operation
#numpy special function


# Numpy is librayary for scientific calvulations in python
# provide array objects
# provide tool for working with array
# container for generic data

import numpy
#create numpy 1 D array
print ("one dimensional array")
a=numpy.array([1,2,3])
print(a)
#create numpy 2 D array
print ("two dimensional array")
a=numpy.array([(1,2,3),(4,5,6),(7,8,9)])
print(a)
