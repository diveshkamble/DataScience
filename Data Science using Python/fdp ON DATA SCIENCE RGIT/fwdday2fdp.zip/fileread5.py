fo=open(r"c:\python\student.txt","r")
str1=fo.read()
print(str1)
# close opened file
fo.close()
print ("work done")
