#Numpy operation
# squre root std deviation
import numpy as np
a=np.array([(1,2,3),(3,4,5)])
print(" Array :\mn",a)
print("Square root : \n",np.sqrt(a))
print("Mean : \n",np.mean(a))
print("std deviation :\n",np.std(a))

# std deviation
# fimd mean of elements
# elements deviates
