#Numpy operation
import numpy as np
ar=np.array([1,2,3])
print("array :",ar)
print(np.exp(ar))
# natural log ie log base e
print(np.log(ar))
# log base 10
print(np.log10(ar))
